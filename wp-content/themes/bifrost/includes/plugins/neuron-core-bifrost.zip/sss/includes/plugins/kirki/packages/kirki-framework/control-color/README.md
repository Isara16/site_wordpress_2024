# kirki-framework/control-color

Install using composer:

```bash
composer require kirki-framework/control-color
```

For documentation please visit the [Kirki Docs](https://kirki.org/docs/controls/color).
